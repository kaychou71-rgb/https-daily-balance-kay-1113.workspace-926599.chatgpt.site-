import catalog from './catalog.json' with {type:'json'};
export const nutrients = ['cal', 'carbs', 'protein', 'fat'] as const;
export type Nutrient = typeof nutrients[number];
export type Nutrition = Record<Nutrient, number>;
export const labels: Record<Nutrient,string> = {cal:'熱量',carbs:'碳水',protein:'蛋白質',fat:'脂肪'};
export const mealTypes = ['早餐','午餐','晚餐','點心'] as const;
export type Food = Nutrition & {id:string;name:string;unit:string;tags:string[];custom?:boolean;favorite?:boolean};
export type Meal = Nutrition & {id:string;name:string;date:string;type:string;servings:number;photo?:string;fatKnown?:boolean};
export type State = {version:2;meals:Meal[];foods:Food[];goals:Nutrition|null;avoid:string;weights:{date:string;kg:number}[]};
export const emptyState:State={version:2,meals:[],foods:[],goals:null,avoid:'',weights:[]};
export function dateKey(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function shiftDate(date:string,days:number){const d=new Date(date+'T12:00:00');d.setDate(d.getDate()+days);return dateKey(d);}
export function round(n:number){return Math.round(n*10)/10;}
export function id(){return Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
export function totals(meals:Meal[]):Nutrition{return meals.reduce((a,m)=>{for(const k of nutrients)a[k]+=m[k]*m.servings;return a;},{cal:0,carbs:0,protein:0,fat:0});}
export function parseNumber(s:string,max=10000){if(!s.trim())throw Error('請填寫所有數值');const n=Number(s);if(!Number.isFinite(n)||n<0||n>max)throw Error(`請輸入 0–${max} 的有效數值`);return n;}
function record(x:any){return x&&typeof x==='object'&&!Array.isArray(x);}
function text(x:any,max=120){return typeof x==='string'&&x.length<=max;}
function number(x:any,max=10000){return typeof x==='number'&&Number.isFinite(x)&&x>=0&&x<=max;}
function validDate(x:any){if(typeof x!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(x))return false;const d=new Date(x+'T12:00:00');return Number.isFinite(d.getTime())&&dateKey(d)===x;}
function nutrition(x:any){return record(x)&&nutrients.every(k=>number(x[k],k==='cal'?10000:1000));}
export function parseBackup(raw:string):State{
 if(raw.length>40_000_000)throw Error('備份檔過大，請選擇 40 MB 以下的檔案');
 const x=JSON.parse(raw);if(!record(x))throw Error('不是有效備份');
 // Accept the original browser prototype export without inventing missing fat.
 if(x.version===undefined&&Array.isArray(x.meals)&&!x.foods){x.version=2;x.foods=[];x.weights=[];x.avoid='';x.meals=x.meals.map((m:any)=>({...m,fat:m.fat??0,fatKnown:m.fat!==undefined}));if(x.goals?.fat===undefined)x.goals=null;}
 if(x.version!==2||!Array.isArray(x.meals)||!Array.isArray(x.foods)||!Array.isArray(x.weights)||!text(x.avoid,500))throw Error('備份格式不正確或版本不支援');
 if(x.meals.length>50000||x.foods.length>5000||x.weights.length>10000)throw Error('備份筆數超過可匯入範圍');
 for(const m of x.meals){if(!nutrition(m)||!text(m.id)||!text(m.name)||!m.name.trim()||!validDate(m.date)||!mealTypes.includes(m.type)||!number(m.servings,100)||m.servings===0||(m.fatKnown!==undefined&&typeof m.fatKnown!=='boolean')||(m.photo!==undefined&&!(typeof m.photo==='string'&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(m.photo))))throw Error('餐點資料格式不正確');}
 for(const f of x.foods){if(!nutrition(f)||!text(f.id)||!text(f.name)||!f.name.trim()||!text(f.unit)||!Array.isArray(f.tags)||!f.tags.every((t:any)=>text(t))||(f.favorite!==undefined&&typeof f.favorite!=='boolean'))throw Error('食物資料格式不正確');}
 for(const w of x.weights)if(!record(w)||!validDate(w.date)||!number(w.kg,500)||w.kg===0)throw Error('體重資料格式不正確');
 if(x.goals!==null&&(!nutrition(x.goals)||nutrients.some(k=>x.goals[k]<=0)))throw Error('目標資料格式不正確');
 if(new Set(x.meals.map((m:Meal)=>m.id)).size!==x.meals.length||new Set(x.foods.map((f:Food)=>f.id)).size!==x.foods.length)throw Error('備份包含重複的紀錄編號');
 return {version:2,meals:x.meals,foods:x.foods,goals:x.goals,avoid:x.avoid,weights:x.weights};
}
// Editable reference estimates, not a verified branded-food database.
export const referenceFoods:Food[]=catalog.foods;
export const recipeTemplates=catalog.recipes;
export const ideaCategories=['全部',...new Set(recipeTemplates.map(r=>r.category))];
export function foodList(state:State){const customIds=new Set(state.foods.map(f=>f.id));return [...state.foods,...referenceFoods.filter(f=>!customIds.has(f.id))];}
export function suggestions(state:State,date:string,category='全部'){
 const foods=foodList(state);const avoid=state.avoid.split(/[、,，\s]+/).filter(Boolean);const total=totals(state.meals.filter(m=>m.date===date));
 return recipeTemplates.filter(r=>category==='全部'||r.category===category)
 .map(recipe=>({recipe,items:recipe.foodIds.map(i=>foods.find(f=>f.id===i)!)}))
 .filter(({items})=>items.every(f=>f&&!avoid.some(a=>`${f.name} ${f.tags.join(' ')}`.includes(a))))
 .map(({recipe,items})=>{const sum=totals(items.map(f=>({...f,date,type:recipe.mealType,servings:1})));const score=state.goals?nutrients.reduce((s,k)=>s+Math.abs(Math.max(0,state.goals![k]-total[k])-sum[k])/state.goals![k],0):0;return {recipe,items,sum,score};}).sort((a,b)=>a.score-b.score);
}


export function buildMix(foods:Food[],selection:Record<string,string>,date:string,type:string):Meal[]{
 return Object.entries(selection).map(([key,raw])=>{const food=foods.find(f=>f.id===key);if(!food)throw Error('找不到已選食物');const servings=parseNumber(raw,100);if(servings<.1)throw Error('每項份數需介於 0.1–100');return {id:id(),name:`${food.name}（${food.unit}／份）`,date,type,servings,cal:food.cal,protein:food.protein,carbs:food.carbs,fat:food.fat,fatKnown:true};});
}
