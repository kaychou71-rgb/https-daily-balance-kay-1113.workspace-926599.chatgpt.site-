import AsyncStorage from '@react-native-async-storage/async-storage';
import {emptyState,parseBackup,State} from './model';
const KEY='daily-balance-native-v2';
export async function readState():Promise<State>{const raw=await AsyncStorage.getItem(KEY);return raw?parseBackup(raw):{...emptyState};}
export async function writeState(state:State){const json=JSON.stringify(state);parseBackup(json);await AsyncStorage.setItem(KEY,json);}
