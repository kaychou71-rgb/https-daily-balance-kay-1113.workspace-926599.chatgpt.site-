# 日常・飲食日記 — iPhone 原生專案

React Native + Expo SDK 58，繁體中文、簡約介面。個人離線使用，沒有 AI 費用。

## 已實作

- 早餐／午餐／晚餐／點心紀錄，新增、修改、刪除、複製到今天。
- 熱量、碳水、蛋白質、脂肪；每份數值乘份數；自行設定每日目標。
- 食物搜尋、自訂食物、修改參考值、收藏常用食物。
- 拍照、選照片、預覽、隨餐點保存；照片不會送往 AI。
- 固定餐點組合依剩餘營養目標排序；可設定忌口字詞過濾。
- 七日營養紀錄、體重新增／修改／刪除。
- JSON 備份與還原，包含照片；還原前驗證格式及確認覆蓋。
- 本機儲存失敗會保留畫面輸入；啟動讀取失敗不會清空原資料。

## 尚未完成／限制

- 尚未建立 Apple Developer、Expo 雲端專案，未簽署 IPA、未上傳 TestFlight、未在實體 iPhone 驗證。
- 內建 32 種參考食物（估值），不是已驗證的完整食品資料庫。可自行輸入包裝數值。AI 食物辨識依使用者要求暫不接入。
- 目前有 8 類、24 組規則式搭配，不是 AI 營養師；忌口是字詞過濾，不能判斷交叉污染或保證過敏安全。
- 無雲端同步。刪除 App 可能刪除資料。單張照片約 1 MB 上限、整份 JSON 40 MB 上限，應定期備份；長期大量照片需改用獨立檔案儲存。
- 舊網頁版資料不會自動搬到手機；解析器支援原網頁版資料格式，但原網頁版尚未提供匯出按鈕。
- 此專案的 web 輸出僅供畫面開發預覽，iOS 確認對話框、相機、分享與檔案選擇應在 iPhone 驗證。

## 開發與檢查

需要 Node.js LTS 與 pnpm（專案使用 pnpm-lock.yaml）。

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm start
pnpm export:ios
```

啟動後可用支援此 SDK 版本的 Expo Go 在同一網路測試；若 Expo Go 版本不相容，需要開發／TestFlight 建置。`expo export --platform ios` 僅產生 JS/Hermes 程式包，不會產生簽署 IPA。

## TestFlight 交付步驟

1. 使用者自行加入 Apple Developer Program，並建立／登入 Expo 帳號。不要把密碼、驗證碼或私鑰貼在聊天中。
2. 在自己的終端機執行 `pnpm dlx eas-cli login`，再執行 `pnpm dlx eas-cli init` 綁定專案。
3. 確認 `app.json` 的 `ios.bundleIdentifier` 可用（目前預設 `com.kay.dailybalance`），首次發佈前可更換。EAS 專案 ID、Apple Team ID 目前均未捏造填入。
4. 執行 `pnpm dlx eas-cli build --platform ios --profile production`，透過 Apple 帳號互動完成簽署設定。
5. 在 App Store Connect 建立同 bundle ID 的 App，取得 Apple App ID。依 EAS 提示設定提交，執行 `pnpm dlx eas-cli submit --platform ios --profile production`。
6. 完成 TestFlight 的必要資訊、Apple 處理／適用審查後，加入測試者，在 iPhone TestFlight 安裝。

官方流程：https://docs.expo.dev/submit/ios/ 及 https://developer.apple.com/programs/

## 本次驗證

- TypeScript 型別檢查通過。
- 11 項自動測試：四項營養乘份數、含照片備份來回、舊版缺失脂肪、無效數值／日期／照片／重複 ID、跨月日期、忌口篩選、食物覆寫。
- Expo iOS export（Hermes）成功。
- 實機權限拒絕、相機照片保存、重新開啟、iOS 檔案分享／還原、鍵盤與安全邊界：待 iPhone 實測。
- 已透過共用 web 畫面驗證新增餐點、四項營養乘以 1.5 份，以及重新載入後的本機儲存。這不取代 iPhone 實機驗證。

## 自由組餐更新

搭配靈感逐項列出食物與每份四項營養。可跨類別選取，或搜尋所有食物，調整各項份數並顯示小計與整餐總和。同食物只計一次。選擇餐別後一次儲存，各項食物保留為可單獨編輯的紀錄。尚未儲存的組合是暫存選擇，離開原生靈感頁後不保留。
